#[[#ifndef]]# ${INCLUDE_GUARD}
#[[#define]]# ${INCLUDE_GUARD}

${NAMESPACES_OPEN}

class ${NAME}
{
};

${NAMESPACES_CLOSE}

#[[#endif]]# //${INCLUDE_GUARD}
